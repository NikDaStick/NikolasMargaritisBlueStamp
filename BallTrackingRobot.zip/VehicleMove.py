import Motor
import RPi.GPIO as GPIO
class VehicleMove:
    def __init__(self):
        self.leftMotor = Motor.Motor(15, 18)
        self.rightMotor = Motor.Motor(21, 16)
        
    def forward(self):
        print("forward")
        self.rightMotor.forward()
        self.leftMotor.forward()
        
    def backward(self):
        print("backward")
        self.rightMotor.backward()
        self.leftMotor.backward()
        
    def rightTurn(self):
        print("rightTurn")
        self.rightMotor.backward()
        self.leftMotor.forward()
        
    def leftTurn(self):
        print("leftTurn")
        self.rightMotor.forward()
        self.leftMotor.backward()

    def stop(self):
        print("stop")
        self.rightMotor.stop()
        self.leftMotor.stop()
