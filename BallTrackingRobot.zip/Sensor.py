import RPi.GPIO as GPIO
import time
class Sensor:
	def __init__(self, trig, echo):
		self.trig = trig
		self.echo = echo
		
		GPIO.setmode(GPIO.BOARD)
		GPIO.setup(self.trig, GPIO.OUT)
		GPIO.setup(self.echo, GPIO.IN)
		
	def distance(self):
		GPIO.output(self.trig, True)
		time.sleep(0.00001)
		GPIO.output(self.trig, False)
		
		startTime = time.time()
		stopTime = time.time()
		
		while (GPIO.input(self.echo) == 0):
			startTime = time.time()
		
		while (GPIO.input(self.echo) == 1):
			stopTime = time.time()
			
		timeElapsed = stopTime - startTime
		distance = (timeElapsed * 34300) /2
		
		return distance
