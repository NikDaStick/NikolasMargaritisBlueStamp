import RPi.GPIO as GPIO
class Motor:
    def __init__(self, pinIn, pinOut):
        self.pinIn = pinIn
        self.pinOut = pinOut
        
        GPIO.setmode(GPIO.BOARD)
        GPIO.setup(self.pinIn, GPIO.OUT)
        GPIO.setup(self.pinOut, GPIO.OUT)
    
    def forward(self):
        GPIO.output(self.pinIn, True)
        GPIO.output(self.pinOut, False)
        
    def backward(self):
        GPIO.output(self.pinIn, False)
        GPIO.output(self.pinOut, True)
        
    def stop(self):
        GPIO.output(self.pinIn, False)
        GPIO.output(self.pinOut, False)
    
